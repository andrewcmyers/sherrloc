include EzyFeatures

let configure modules objs = EzyDynload.Teachpack.config_result := Some (modules, objs)

