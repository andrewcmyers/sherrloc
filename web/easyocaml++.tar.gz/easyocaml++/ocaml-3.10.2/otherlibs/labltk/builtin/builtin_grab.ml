(* type *)
type grabGlobal = bool
(* /type *)
