package sherrloc.graph;

/**
 * Variance of parameters
 */
public enum Variance {POS, NEG, BOTH}